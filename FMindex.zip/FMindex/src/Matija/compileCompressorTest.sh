#!/bin/bash
g++ -o compressorTest.exe compressorMain.cpp Compressor.cpp Alphabet.cpp
