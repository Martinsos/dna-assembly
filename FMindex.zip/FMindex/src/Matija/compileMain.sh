# Compiles Opp structure for testing
g++ -Wall -o oppTest.exe Opp.cpp oppMain.cpp
