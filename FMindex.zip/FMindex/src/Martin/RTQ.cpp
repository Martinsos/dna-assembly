#include "RTQ.hpp"

using namespace std;

RTQ::RTQ (const vector< pair<Index,Index> >& Q, const vector<Index>& V)
{
}

vector<Index> RTQ::query(Index xMin, Index xMax, Index yMin, Index yMax)
{
    return vector<Index>();
}
