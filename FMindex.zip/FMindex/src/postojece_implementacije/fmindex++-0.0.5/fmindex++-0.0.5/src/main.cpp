#include <iostream>
#include "fmIndex.hpp"

using namespace std;

int main(int argc, char **argv){
  fmIndex fm;
  fm.run(argv[1]);
}
