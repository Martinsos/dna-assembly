/*******************************************************************************
+
+  LEDA 6.3  
+
+
+  geo_localdefs.h
+
+
+  Copyright (c) 1995-2010
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/


#define GeoWinVersion       1.1
#define GeoWinFileFormat    0.9

#define MAXIMUM_SCENETYPES   1024


#define GEO_MSG_CLOSE      532
#define GEO_MSG_CLEAR      533

// menu defines


