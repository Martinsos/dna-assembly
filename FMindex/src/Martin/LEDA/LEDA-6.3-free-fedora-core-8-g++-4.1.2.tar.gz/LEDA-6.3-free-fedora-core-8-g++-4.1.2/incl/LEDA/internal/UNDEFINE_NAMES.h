/*******************************************************************************
+
+  LEDA 6.3  
+
+
+  UNDEFINE_NAMES.h
+
+
+  Copyright (c) 1995-2010
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/


// for backward compatibility
// please use <LEDA/internal/POSTAMBLE.h>

#include <LEDA/internal/POSTAMBLE.h>
