/*******************************************************************************
+
+  LEDA 6.3  
+
+
+  random.h
+
+
+  Copyright (c) 1995-2010
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/



#include <LEDA/core/random_source.h>

